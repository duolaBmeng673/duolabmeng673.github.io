# WM算法

> Wu-Manber：快速的多模式匹配算法。预处理阶段构建 **SHIFT / HASH / PREFIX / PAT_PTR** 四张表，搜索阶段先用 SHIFT 表“大步跳过”，只有 SHIFT 值为 0 时才用 HASH、PREFIX、PAT_PTR 逐步缩小候选并验证。

## 1 例题与约定

- 模式集：`{thinner, shining, church, touching, thinking}`
- 正文：`Tomisthinkinghowtobethinner`（统一转小写处理，共 27 个字符）
- 最短模式 `church`，所以 **m = 6**；块长 **B = 2**；前缀长度 **B′ = 2**
- 哈希函数（由 PPT 中各二元组的哈希值反推）：`hash(xy) = (x 的序号 + y 的序号) mod 29`，`a=0 … z=25`
  例：`th = 19+7 = 26`，`ur = 20+17 = 37 mod 29 = 8`
- 交互模拟：[wm_simulator.html](wm_simulator.html)

> PPT 勘误：第 2 页字符表下标 9 处写成了 `g`，应为 `j`（不影响本例计算）。

## 2 预处理

### 2.1 截断与分块

把所有模式截断为前 m 个字符，再取每个长度为 B 的子串（结束位置 q = 2…m），计算其哈希值。

- `thinner → thinne`：th(26) hi(15) in(21) nn(26) ne(17)
- `shining → shinin`：sh(25) hi(15) in(21) ni(21) in(21)
- `church → church`：ch(9) hu(27) ur(8) rc(19) ch(9)
- `touching → touchi`：to(4) ou(5) uc(22) ch(9) hi(15)
- `thinking → thinki`：th(26) hi(15) in(21) nk(23) ki(18)

![模式截断与分块](svg/wm_1_blocks.svg)

### 2.2 SHIFT 表

**作用**：搜索时决定文本指针右移多少。

- 类似 Boyer-Moore 的坏字符表，但移动距离基于**最后 B 个字符**，而不是一个字符。
- 当前 B 字符子串未在任何模式中出现 → 可移动 `m−B+1`；若出现，则取它在模式中最右结束位置 q，移动 `m−q`。
- 值 **> 0 可安全移动**；值 **= 0 才可能匹配**，进入 HASH 表继续判断。

**构建**：全部初始化为 `m−B+1 = 5`；对每个模式的每个 B 子串（结束位置 q），令 `SHIFT[h] = min(SHIFT[h], m−q)`。

- 例：`ne`（q=6）→ 0；`ki`、`hi`、`in`、`ch` 也都在某个模式的末尾出现 → 0
- `th`(26)：q=2 → 4，`nn`(26)：q=5 → 1，二者哈希相同，取 min 得 **SHIFT[26] = 1**
- `in`(21)：q=4 → 2 / q=6 → 0，`ni`(21)：q=5 → 1，取 min 得 **SHIFT[21] = 0**

![SHIFT 表](svg/wm_2_shift.svg)

### 2.3 HASH 表

**作用**：SHIFT 为 0 时，避免把文本与全部模式逐一比较，只取出“末 B 字符哈希相同”的候选模式列表。

- 下标与 SHIFT 表相同（同一个 h，可复用哈希计算结果）；`HASH[h]` 指向末 B 字符哈希为 h 的模式链表。
- 表很稀疏（只含各模式的结尾子串），内存利用率低，但省去重复计算。

本例：`HASH[9]=P2`，`HASH[15]=P3`，`HASH[17]=P0`，`HASH[18]=P4`，`HASH[21]=P1`。

![HASH 表](svg/wm_3_hash.svg)

### 2.4 PREFIX 表与 PAT_PTR 表

**PREFIX 表的作用**：自然语言里 `ing`、`ion` 等后缀很常见，会让很多模式落到 HASH 表同一入口。PREFIX 表保存每个模式**开头 B′ 个字符**的哈希（实现中 B′=2），搜索时先比窗口前缀，**后缀相同而前缀不同的模式直接过滤**。

**PAT_PTR 表的作用**：保存模式编号到完整模式串（未截断）的指针，用于最终逐字符验证。

| 编号 | PAT_PTR | PREFIX（前缀→hash） |
| --- | --- | --- |
| 0 | thinner | th → 26 |
| 1 | shining | sh → 25 |
| 2 | church | ch → 9 |
| 3 | touching | to → 4 |
| 4 | thinking | th → 26 |

![PREFIX 与 PAT_PTR](svg/wm_4_prefix_patptr.svg)

### 2.5 四表关系

![四表协作关系](svg/wm_5_relations.svg)

## 3 搜索过程

从文本第 m 个字符开始自左向右扫描，每次读入 `t[pos−B+1..pos]`：

1. 计算这 B 个字符的 hash 值 h；
2. 查 `SHIFT[h]`：> 0 则文本指针右移该值，回到 1；= 0 继续；
3. 计算窗口前缀（窗口起点向右 B′ 个字符）的 hash；
4. 查 `HASH[h]` 中各候选的 PREFIX，不等则淘汰；
5. 对前缀相等的候选，从 PAT_PTR 取出模式串与文本逐字比较，匹配则输出；
6. 无论是否匹配，文本指针右移 1 位，回到 1，直到文本结束。

## 4 例子模拟

| 步 | pos | 末2字符 | h | SHIFT | 动作 |
| --- | --- | --- | --- | --- | --- |
| 1 | 6 | st | 8 | 2 | 右移 2 |
| 2 | 8 | hi | 15 | 0 | HASH[15]={P3}；窗口前缀 `mi`=20 ≠ PREFIX[3]=4 → 右移 1 |
| 3 | 9 | in | 21 | 0 | HASH[21]={P1}；前缀 `is`=26 ≠ 25 → 右移 1 |
| 4 | 10 | nk | 23 | 1 | 右移 1 |
| 5 | 11 | ki | 18 | 0 | HASH[18]={P4}；前缀 `th`=26 = 26，比较 `thinking` ✓ **匹配（第 6–13 位）** → 右移 1 |
| 6 | 12 | in | 21 | 0 | P1；前缀 `hi`=15 ≠ 25 → 右移 1 |
| 7 | 13 | ng | 19 | 1 | 右移 1 |
| 8 | 14 | gh | 13 | 5 | 右移 5 |
| 9 | 19 | ob | 15 | 0 | P3；前缀 `ho`=21 ≠ 4 → 右移 1 |
| 10 | 20 | be | 5 | 3 | 右移 3 |
| 11 | 23 | hi | 15 | 0 | P3；前缀 `ob`=15 ≠ 4 → 右移 1 |
| 12 | 24 | in | 21 | 0 | P1；前缀 `be`=5 ≠ 25 → 右移 1 |
| 13 | 25 | nn | 26 | 1 | 右移 1 |
| 14 | 26 | ne | 17 | 0 | HASH[17]={P0}；前缀 `th`=26 = 26，比较 `thinner` ✓ **匹配（第 21–27 位）** → 右移 1 |
| 15 | 27 | er | 21 | 0 | P1；前缀 `hi`=15 ≠ 25 → 右移 1，pos=28 > 27，结束 |

结果：`thinking`（第 6 位）、`thinner`（第 21 位）。27 个字符只检查了 15 个窗口，其中 6 次由 SHIFT 直接跳过，9 次进入 HASH/PREFIX 校验。前 3 步与 PPT 第 24–26 页的演示一致。

## 5 参考代码（Python）

```python
def H(s, M=29): return sum(ord(c) - 97 for c in s) % M

def build(pats, B=2, M=29, BP=2):
    m = min(map(len, pats)); pt = [p[:m] for p in pats]
    shift = [m - B + 1] * M; hash_t = {}; prefix = []
    for i, p in enumerate(pt):
        for q in range(B, m + 1):                      # 每个 B 子串，结束位置 q
            h = H(p[q - B:q], M); shift[h] = min(shift[h], m - q)
        hash_t.setdefault(H(p[m - B:], M), []).append(i)   # HASH：末 B 字符
        prefix.append(H(p[:BP], M))                         # PREFIX：前 B' 字符
    return m, shift, hash_t, prefix

def search(text, pats, B=2, M=29, BP=2):
    m, shift, hash_t, prefix = build(pats, B, M, BP)
    n, pos, res = len(text), m, []
    while pos <= n:
        h = H(text[pos - B:pos], M)
        if shift[h] > 0:
            pos += shift[h]; continue
        s = pos - m; hp = H(text[s:s + BP], M)
        for i in hash_t.get(h, []):
            if prefix[i] == hp and text.startswith(pats[i], s):   # PAT_PTR 验证
                res.append((s + 1, pats[i]))
        pos += 1
    return res

print(search("tomisthinkinghowtobethinner",
             ["thinner", "shining", "church", "touching", "thinking"]))
# [(6, 'thinking'), (21, 'thinner')]
```
